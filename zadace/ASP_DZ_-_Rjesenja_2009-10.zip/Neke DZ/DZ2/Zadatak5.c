/*
Zadane su strukture koje definiraju red i stog, te funkcije za inicijalizaciju reda  i stoga te skidanje i stavljanje elemenata na stog odnosno red.


Prototipovi funkcija su:


void init_stog(Stog *stog);

int dodajNaStog (int element, Stog *stog);

int skiniSaStoga (int *element, Stog *stog);


void init_red(Red *red);

int dodajURed (int element, Red *red);

int skiniIzReda (int *element, Red *red);





Funkcije za skidanje elemenata vraćaju 1 ako je skidanje uspješno obavljeno, a inače 0. Može se pretpostaviti da će stavljanje elementa na stog ili red uvijek biti uspješno obavljeno.




Koristeći definirane funkcije napisati funkciju čiji je prototip:


void StogURed(Stog *stog, Red *red);





Funkcija treba prepisati elemente stoga u red na način da element koji je zadnji ušao u stog mora zadnji ući u red. Stog nakon izvođenja funkcije mora ostati nepromijenjen!





Predati samo treženu funkciju, bez glavnog programa!
*/
void StogURed(Stog *stog, Red *red)
{
    Stog tmp;

    int e;

    init_stog(&tmp);

    while(skiniSaStoga(&e, stog))
        dodajNaStog(e, &tmp);

    while(skiniSaStoga(&e, &tmp)) {
        dodajNaStog(e, stog);
        dodajURed(e, red);
    }
}
