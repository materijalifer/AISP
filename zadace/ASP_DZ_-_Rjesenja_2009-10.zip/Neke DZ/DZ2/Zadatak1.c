/**
Napisati funkciju koja će prebaciti sadržaj stoga u red na način da u konačnici elementi bliže vrhu stoga budu elementi bliže izlazu iz reda (prvi element s vrha stoga odlazi na poziciju prvog elementa koji izlazi iz reda, drugi element s vrha stoga na poziciju drugog elementa koji izlazi iz reda itd). Funkcija mora biti rekurzivna i imati prototip:


void prebaci_stog_u_red(Stog *stog, Red* red)


Redovima se smije pristupati jedino funkcijama:


int DodajURed (int element, Red *red);

int SkiniIzReda (int *element, Red *red);


Stogovima se smije pristupati jedino funkcijama:


int dodaj (tip element, Stog *stog);

int skini (tip *element, Stog *stog);


Za inicijalizaciju redova i stogova prije prvog korištenja koristiti funkcije:


void init_red(Red *red);

void init_stog(Stog *stog);
*/

void prebaci_stog_u_red(Stog *stog, Red* red)
{
    Stog tmp;

    int e;

    init_stog(&tmp);

    while(skini(&e, stog)) {
        dodaj(e, &tmp);
        DodajURed(e, red);
    }

    while(skini(&e, &tmp))
        dodaj(e, stog);
}
