/*
Napisati rekurzivnu funkciju koja će izračunati i vratiti sumu prvih N članova slijedećeg reda:



1/((4i-1)*(4i+1)


Funkcija mora imati prototip:



double sumareda(int N);



Unutar tijela funkcije, nakon definicija lokalnih varijabli, obavezno dodati poziv slijedeće funkcije:



int kontrola();



Dakle, programski kod treba imati strukturu:



double sumareda(int N) {

     // definicije vaših lokalnih varijabli

     kontrola(); // ne treba primati povratnu vrijednost

     // ostatak funkcije

}



Funkcija kontrola koristi se prilikom testiranja je li predano rješenje rekurzivno i ne trebate ju pisati i predavati. Prilikom isprobavanja možete koristiti "praznu" funkciju:



int kontrola(){return 0;}
*/

double sumareda(int N)
{
    kontrola();

    if (N == 0)
        return 0.;

    return sumareda(N - 1) + 1. / ((4 * N - 1) * (4 * N + 1));
}