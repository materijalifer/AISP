/**
Napišite funkciju koja će preko parametara uzimati dva cjelobrojna polja te ih ujediniti u novo cjelobrojno polje na način da ono sadrži samo dvoznamenkaste elemente iz oba polja.

Npr. za polje A = 1,22,3,444 i za polje B = 11, 0, -1, -22 mora se stvoriti novo polje C = 22, 11, -22 (redoslijed elemenata u polju C nije bitan, a duplikate, ukoliko postoje, treba očuvati).

Novonastalo polje vratiti preko imena funkcije (naredbom return), a broj elemenata u polju preko parametra int *Nc.



int* napraviPolje(int *A, int Na, int*B, int Nb, int* Nc)



int *A je pokazivač na prvi element polja A

int Na je broj elemenata u polju A

int *B je pokazivač na polje B

int Nb je broj elemenata u polju B

int* Nc je parametar koji će u pozivajući program vratiti broj elemenata u novonastalome polju.

Napomena: Obavezno koristiti funkciju malloc (ili realloc)!
*/

int abs(int broj)
{
    if (broj < 0)
        return -broj;

    return broj;
}

int* napraviPolje(int *A, int Na, int*B, int Nb, int* Nc)
{
    int *temp = NULL;

    int i, broj = 0;

    for (i = 0; i < Na; i++) {
        if (abs(*(A + i)) > 9 && abs(*(A + i)) < 100) {
            temp = (int *) realloc(temp, (++broj) * sizeof(int));
            *(temp + broj - 1) = *(A + i);
        }
    }

    for (i = 0; i < Nb; i++) {
        if (abs(*(B + i)) > 9 && abs(*(B + i)) < 100) {
            temp = (int *) realloc(temp, (++broj) * sizeof(int));
            *(temp + broj - 1) = *(B + i);
        }
    }

    *Nc = broj;

    return temp;
}
