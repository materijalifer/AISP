/**
Neka je zadana slijedna neformatirana datoteka u kojoj se nalaze zapisi oblika:

     struct album{

         char naziv[30+1];

         char autor[20+1];

         int prodano;

    };

Napisati funkciju koja će za zadanog autora vratiti broj prodanih primjeraka albuma (prodano).

Prototip funkcije mora biti:

            int br_prodanih(FILE *f, char *autor);



Ako zadani autor ima više od jednog albuma, funkcija treba vratiti zbroj prodanih primjeraka svih njegovih albuma.
*/

int br_prodanih(FILE *f, char *autor)
{
    album jedanAlbum;

    int n = 0;

    while (fread(&jedanAlbum, sizeof(jedanAlbum), 1, f) == 1) {
        if (strcmp(jedanAlbum.autor, autor) == 0)
            n += jedanAlbum.prodano;
    }

    return n;
}
