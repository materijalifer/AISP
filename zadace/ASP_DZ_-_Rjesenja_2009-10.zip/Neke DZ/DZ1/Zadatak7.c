/**
Napisati funkciju čiji je prototip

 char *StvoriNiz(char *poljeznakova, int duljina, int n)

koja će stvoriti novi niz znakova koji će se sastojati od n slučajno odabranih znakova iz ulaznog polja znakova čija je duljina zapisana u ulaznoj varijabli duljina. Znakovi se mogu ponavljati, a možete pretpostaviti da su n i duljina pozitivni brojevi. Funkcija mora vratiti pokazivač na novostvoreni niz znakova.

Napomena: stvoreni niz znakova mora završiti nul znakom.

Dopuštene biblioteke funkcija: stdio.h, string.h, stdlib.h

Za generiranje slučajnog broja koristite funkciju moj_rand. Za testiranje možete uzeti da funkcija glasi:

 int moj_rand(){ return rand();}

a koristite je kao i u funkciju rand. Npr. moj_rand() % 13

Obavezno koristiti funkciju malloc (ili realloc)!
*/

char *StvoriNiz(char *poljeznakova, int duljina, int n)
{
    char *temp;

    int i;

    temp = (char *) malloc(n * sizeof(char) + 1);

    for (i = 0; i < n; i++) {
        *(temp + i) = *(poljeznakova + (moj_rand() % (duljina + 1)));
    }

    *(temp + i) = 0;

    return temp;
}
