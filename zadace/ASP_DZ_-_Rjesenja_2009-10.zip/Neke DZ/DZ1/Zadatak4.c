/**
Napisati funkciju čiji je prototip

char *brojeve_u_znakove(int *polje, int duljina)

koja će stvoriti niz znakova koji će sadržavati brojeve iz ulaznog polja napisane u obrnutom redoslijedu i to bez međusobnih razmaka te bez vodećih i pratećih praznina. Npr. ukoliko je ulazni polje sadržavalo brojeve 123, 15, 200, 84, 1021 i 7 funkcija će stvoriti novi niz koji će imati sadržaj "321510024812017". Funkcija mora vratiti pokazivač na novostvoreni niz znakova. Ukoliko je ulazni niz bio duljine 0, funkcija mora vratiti prazan niz. Možete pretpostaviti da su svi brojevi u polju pozitivni.

Dopuštene biblioteke funkcija: stdio.h, string.h, stdlib.h, math.h
*/

#include <stdio.h>
#include <math.h>

void obrniRedIPretvoriUString(int broj, char *polje, int brZnak)
{
    //Svi brojevi izašli?
    if (brZnak == 0)
        return;

    //Napravi mod 10 i dodaj 48 da dobijemo ASCII znak
    *polje = (broj % 10) + 48;

    //Pozovi za sljedeću težinu
    return obrniRedIPretvoriUString(broj / 10, polje + 1, brZnak - 1);
}

char *brojeve_u_znakove(int *polje, int duljina)
{
    int i, brZnakova, sveDoSad = 0; //Početne varijable

    char *temp = NULL; ; //To će biti naš string

    for (i = 0; i < duljina; i++) {

        //Log(1) je 0 pa moramo provjerit
        if (*(polje + i) > 1)
            brZnakova = (int) ceil(log10(*(polje + i)));
        else
            brZnakova = 1;

        //Sveukupna duljina
        sveDoSad += brZnakova;

        //Podižemo za +brojZnakova
        temp = (char *) realloc(temp, sveDoSad);

        //Obrni red i pretvori u string. Šaljemo broj i dio na koji nadodajemo brojeve. Također pratimo koliko težina imamo
        obrniRedIPretvoriUString(*(polje + i), temp + sveDoSad - brZnakova, brZnakova);
    }

    //Dodaj još 0 na kraj
    temp = (char *) realloc(temp, ++sveDoSad);
    *(temp + sveDoSad) = 0;

    return temp;
}

int main()
{
    int polje[6] = {0};

    char *str;

    str = brojeve_u_znakove(polje, 1);

    puts(str);

    free(str);

    return 0;
}