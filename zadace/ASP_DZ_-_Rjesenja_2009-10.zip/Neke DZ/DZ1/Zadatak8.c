/**
Neka je zadana slijedna formatirana datoteka u kojoj se nalaze podaci o albumima:

            naziv         (char[30+1])

autor    (char[20+1])

prodano  (int)

 (Podaci o jednom albumu zapisani su u jednom retku, odvojeni jednim razmakom. Pretpostaviti da  naziv  i  autor ne sadrže praznine.)

Napisati funkciju koja će vratiti broj albuma za koje je prodano granica ili više primjeraka.

Prototip funkcije mora biti:

            int veci_od(FILE *f, int granica);
*/

int veci_od(FILE *f, int granica)
{
    char naziv[30 + 1], autor[20 + 1];
    int prodano, n = 0;
    char c;

    while (fscanf(f, "%s%c%s%c%d%c", naziv, &c, autor, &c, &prodano, &c) == 6) {
        if (prodano > granica)
            n++;
    }

    return n;
}
