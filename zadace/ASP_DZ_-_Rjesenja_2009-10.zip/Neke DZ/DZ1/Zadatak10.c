/**
Napisati funkciju čiji je prototip

 char *SamoDuplikati(char *ulazni_niz)

koja će na osnovu ulaznog niza stvoriti novi niz koji bi nastao uzimanjem znakova tek nakon što se pojave drugi ili neki veći put u ulaznom nizu Npr. ukoliko je ulazni niz bio "ABCDA123D32A1", funkcija će stvoriti novi niz koji će imati sadržaj "AD32A1" (dakle u ovom primjeru, iz ulaznog niza uzeti su masno označeni znakovi) Funkcija mora vratiti pokazivač na novostvoreni niz znakova. Ukoliko je ulazni niz bio prazan ili je bio NULL, funkcija treba vratiti NULL pokazivač. Ukoliko u ulaznom nizu nema duplikata vratiti prazan niz znakova. Napomena : Ulazni niz mora ostati nepromijenjen.

Dopuštene biblioteke funkcija: stdio.h, string.h, stdlib.h

Obavezno koristiti funkciju malloc (ili realloc)!
*/

char *SamoDuplikati(char *ulazni_niz)
{

    char *temp = NULL;

    int pozicija = 0, n = 0;

    if (ulazni_niz == NULL || *ulazni_niz == 0)
        return temp;

    while (*(ulazni_niz + pozicija) != 0) {

        if (strchr(ulazni_niz, *(ulazni_niz + pozicija)) - (ulazni_niz + pozicija) < 0) {
            temp = (char *) realloc(temp, (++n) * sizeof(char));
            *(temp + n - 1) = *(ulazni_niz + pozicija);
        }

        pozicija++;
    }

    temp = (char *) realloc(temp, (++n) * sizeof(char));
    *(temp + n - 1) = 0;

    return temp;
}
