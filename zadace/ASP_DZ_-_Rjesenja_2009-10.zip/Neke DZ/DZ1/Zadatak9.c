/**
Napisati funkciju čiji je prototip

 char *SamoSamoglasnici(char *ulazni_niz)

koja će na osnovu ulaznog niza stvoriti novi niz koji bi nastao izbacivanje svih znakova koji nisu samoglasnici. Npr. ukoliko je ulazni niz bio "AB!Cuu123dE#F", funkcija će stvoriti novi niz koji će imati sadržaj "AuuE". Funkcija mora vratiti pokazivač na novostvoreni niz znakova. Ukoliko je ulazni niz bio prazan ili je bio NULL, funkcija treba vratiti NULL pokazivač. Napomena: Ulazni niz mora ostati nepromijenjen.

Dopuštene biblioteke funkcija: stdio.h, string.h, stdlib.h, ctype.h

Obavezno koristiti funkciju malloc (ili realloc)!
*/

int jeSamoglasnik(char ulaz)
{
    char znak = tolower(ulaz);

    return znak == 'a' || znak == 'e' || znak == 'i' || znak == 'o' || znak == 'u';
}

char *SamoSamoglasnici(char *ulazni_niz)
{
    char *temp = NULL;

    int n = 0;

    if (ulazni_niz == NULL || *(ulazni_niz) == 0)
        return temp;

    while (*(ulazni_niz) != 0) {

        if (jeSamoglasnik(*(ulazni_niz))) {
            temp = (char *) realloc(temp, (++n) * sizeof(char));
            *(temp + n - 1) = *ulazni_niz;
        }

        ulazni_niz++;
    }


   temp = (char *) realloc(temp, (++n) * sizeof(char));
   *(temp + n - 1) = 0;


    return temp;
}
