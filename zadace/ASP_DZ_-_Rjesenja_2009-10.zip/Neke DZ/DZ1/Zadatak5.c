/**
Neka je zadana slijedna neformatirana datoteka u kojoj se nalaze zapisi oblika:

     struct album{

         char naziv[30+1];

         char autor[20+1];

         int prodano;

    };

Napisati funkciju koja će vratiti prosječan broj prodanih primjeraka svih albuma.

Prototip funkcije mora biti:

            float prosjek(FILE *f);
*/

float prosjek(FILE *f)
{
    album jedanAlbum;

    float prosjek = 0;

    int n = 0;

    while (fread(&jedanAlbum, sizeof(jedanAlbum), 1, f) == 1) {
        n++;
        prosjek += jedanAlbum.prodano;
    }

    return prosjek / n;
}
