/**
Neka je zadana slijedna neformatirana datoteka u kojoj se nalaze zapisi oblika:

     struct album{

         char naziv[30+1];

         char autor[20+1];

         int prodano;

    };

Napisati funkciju koja će vratiti broj albuma za koje je prodano granica ili više primjeraka.

Prototip funkcije mora biti:

            int veci_od(FILE *f, int granica);
*/

int veci_od(FILE *f, int granica)
{
    album jedanAlbum;

    int broj = 0;

    while(fread(&jedanAlbum, sizeof(album), 1, f) == 1) {
        if (jedanAlbum.prodano >= granica)
            broj++;
    }

    return broj;
}
