/**
Neka je zadana direktna neformatirana datoteka u kojoj se nalaze zapisi oblika:

    struct natjecatelj{

        int redni_br;

        char prezime[20+1];

        int bodovi;

    };

Zapisi su u datoteci sortirani po rednom broju (redni_br) i to tako da redni broj zapisa odgovara rednom broju natjecatelja.
(Datoteka počinje rednim brojem 1. Ako je redni_br = 0, znači da je zapis prazan.)



Napisati funkciju koja za zadani redni broj natjecatelja vraća 1 ako natjecatelj ima više ili jednako 100 bodova, 0 ako ima manje od 100 bodova, a -1 ako je zapis prazan.

Funkcija mora imati prototip:

         int info(FILE *f, int redni_br);
*/

int info(FILE *f, int redni_br)
{
    natjecatelj jedanNatjecatelj;

    fseek(f, (redni_br - 1) * sizeof(natjecatelj), SEEK_SET);

    fread(&jedanNatjecatelj, sizeof(natjecatelj), 1, f);

    if (jedanNatjecatelj.redni_br == 0)
        return -1;

    return jedanNatjecatelj.bodovi >= 100;
}
