/*
U čvor stabla spremaju se cjelobrojan podatak id i znakovni niz naziv.
struct cv {
  int id;
  char naziv[15];
  struct cv *lijevo;
  struct cv *desno;
}; typedef struct cv cvor; Napisati funkciju koja vraća koliko se puta zadani naziv pojavljuje u stablu. Prototip funkcije mora biti: int ModElementa(cvor *glava, char *naziv);

*/

int ModElementa(cvor *glava, char *naziv)
{
    if (glava == NULL)
        return 0;

    return  (strcmp(glava->naziv, naziv) == 0 ? 1 : 0) + ModElementa(glava->lijevo, naziv) + ModElementa(glava->desno, naziv);
}