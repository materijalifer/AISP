/*
U čvor stabla spremaju se cjelobrojan podatak id i znakovni niz naziv.
struct cv {
    int id;
    char naziv[15];
    struct cv *lijevo;
    struct cv *desno;
};

typedef struct cv cvor;

Napisati funkciju koja vraća 1 ako zadano stablo ima svojstvo da svaki čvor
stabla ima najviše jedno dijete, 0 inače. Za prazno stablo funkcija vraća 1.
Prototip funkcije mora biti:

int Najgore(cvor *glava);
*/

int Najgore(cvor *glava)
{
    if (glava == NULL)
        return 1;

    return !(glava->lijevo != NULL && glava->desno != NULL) && Najgore(glava->lijevo) && Najgore(glava->desno);
}