/*
Zadana je struktura:

typedef struct {

      char ime[20+1];

      char prezime[30+1];

      char jmbag[10+1];

      int  ocjena;

} tip;

Potrebno je napisati funkcija za rad s jednostruko povezanom listom koja u svojim atomima sadrži zadane strukture:

Prototip


Opis

int brojElementa(atom *glava)


Vraća broj elemenata u listi.

int dodaj (atom **glavap, tip element)


Dodaje zadani element na početak liste. Vraća 1 ako je uspjela, inače 0.

int minOcjena(atom *glava)


Vraća minimalnu ocjenu odnosno -1 ako je lista prazna..

int izbaciPrezimeSadrzi (atom **glavap, char *prezimePodniz)


Izbacuje element iz liste ako prezime sadrži  zadani podniz (velika i mala slova se razlikuju).  Vraća broj izbačenih elemenata.

int izbaciPrezimePocinjeS (atom **glavap, char * prezimePocetak)


Izbacuje element iz liste ako prezime počinje s zadanim podnizom (velika i mala slova se razlikuju).  Vraća broj izbačenih elemenata.

VAŽNA NAPOMENA:

·         Osim funkcija potrebno je predati i deklaracije struktura koje koristite. Predati i deklaraciju gore zadane strukture odnosno tipa podataka tip.

·         Predati treba samo funkcije i strukture, ne i glavni program (main).

·         Nije potrebno uključivati standardne biblioteke funkcija, za sve zadatke uključene su: stdio.h, malloc.h, stdlib.h, math.h, string.h, time.h, conio.h
*/

typedef struct {
      char ime[20+1];
      char prezime[30+1];
      char jmbag[10+1];
      int  ocjena;
} tip;

typedef struct a{
    tip el;
    struct a *sljed;
} atom;

int brojElementa(atom *glava)
{
    atom *tmp;
    int i;

    for (i = 0, tmp = glava; tmp != NULL; tmp = tmp->sljed, i++);

    return i;
}

int dodaj (atom **glavap, tip element)
{
    atom *novi;

    if ((novi = (atom *) malloc(sizeof(atom))) == NULL)
        return 0;

    strcpy ((novi->el).ime, element.ime);
    strcpy ((novi->el).prezime, element.prezime);
    strcpy ((novi->el).jmbag, element.jmbag);
    
    (novi->el).ocjena = element.ocjena;

    novi->sljed = *glavap;

    *glavap = novi;

    return 1;
}

int minOcjena(atom *glava)
{

    atom *tmp;
    int i, min;
    
    if (glava == NULL)
        return -1;

    min = (glava->el).ocjena;

    for (i = 0, tmp = glava->sljed; tmp != NULL; tmp = tmp->sljed, i++) {
        if ((tmp->el).ocjena < min)
            min = (tmp->el).ocjena;
    }

    return min;
}

int izbaciPrezimeSadrzi (atom **glavap, char *prezimePodniz)
{
    atom *tren, *prethd;
    int i = 0;

    if (*glavap == NULL)
        return 0;

    for (tren = (*glavap)->sljed, prethd = *glavap; tren != NULL; prethd = tren, tren = tren->sljed) {
        if (strstr((tren->el).prezime, prezimePodniz) != NULL) {
            prethd->sljed = tren->sljed;
            free(tren);
            tren = prethd;
            i++;
        }
    }

    if (strstr(((*glavap)->el).prezime, prezimePodniz) != NULL) {
        tren = *glavap;
        *glavap = (*glavap)->sljed;
        free(tren);
        i++;
    }

    return i;
}

int izbaciPrezimePocinjeS (atom **glavap, char * prezimePocetak)
{

    atom *tren, *prethd;
    int i = 0;
    
    if (*glavap == NULL)
        return 0;

    for (tren = (*glavap)->sljed, prethd = *glavap; tren != NULL; prethd = tren, tren = tren->sljed) {
        if (strstr((tren->el).prezime, prezimePocetak) == (tren->el).prezime) {
            prethd->sljed = tren->sljed;
            free(tren);
            tren = prethd;
            i++;
        }
    }

    if (strstr(((*glavap)->el).prezime, prezimePocetak) == ((*glavap)->el).prezime) {
        tren = *glavap;
        *glavap = (*glavap)->sljed;
        free(tren);
        i++;
    }

    return i;

}
