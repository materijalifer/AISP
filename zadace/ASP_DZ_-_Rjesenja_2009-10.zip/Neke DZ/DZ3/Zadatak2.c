/*
U čvor sortiranog stabla spremaju se cjelobrojan podatak id i znakovni niz naziv.
struct cv {
  int id;
  char naziv[15];
  struct cv *lijevo;
  struct cv *desno;
};

typedef struct cv cvor;

Napisati funkciju koja preko parametara lijevo i desno vraća koliko se puta
prilikom traženja zadanog elementa (preko id-a) krećemo u stablu lijevo, odnosno desno.
Ako traženog elementa nema u stablu funkcija vraća 0, inače 1 (preko return-a).
Lijevo i desno su postavljene na 0 u main-u. Prototip funkcije mora biti:

int LijevoDesno(cvor *glava, int id, int *lijevo, int *desno);
*/


int LijevoDesno(cvor *glava, int id, int *lijevo, int *desno)
{
    int ima = 0;

    if (glava == NULL)
        return ima;

    if (glava->id == id)
        return 1;

    if (glava->id < id) {
        ima |= LijevoDesno(glava->desno, id, lijevo, desno);
        *desno = *desno + 1;
    }
    else {
        ima |= LijevoDesno(glava->lijevo, id, lijevo, desno);
        *lijevo = *lijevo + 1;
    }

    return ima;
}