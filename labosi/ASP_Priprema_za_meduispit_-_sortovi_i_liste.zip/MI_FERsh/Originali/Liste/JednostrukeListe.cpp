//Prije no sto pocnete gledat/citat ovaj kod, ozbiljno preporucam da procitate uvod u liste kako bi bolje razumjeli kod.
//Jedina tezina kod lista je sintaksa i nemilosrdnost, sto je i ljepota C-baziranih jezika (C#-a malo manje :( )
//Ako savladate sintaksu i pokazivace liste ce vam bit veca sala od videozida FER-a, sretno.

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<ctype.h>

using namespace std;

typedef struct at		//Definirajmo prvo atom, tj. osnovni element liste.
{
	int value;			//To je struktura koja u sebi drži neku vrijednost,
	struct at *next;	//A zatim pokazivac na vlastiti tip strukture
} atom;					//strukturu cemo nazvati atom

//Sada bi htjeli imati mogucnost dodati neki element u nasu strukturu
int add2list (atom **glavap, int value)
{
	atom *novi;							//Definiramo pokazivac na neki novi atom
	novi = (atom*)malloc(sizeof(atom));	//Alocirati cemo memoriju na heapu za 1 atom.
	
	if(!novi)							//Ako novi pokazuje na 0, alociranje memorije nije uspjelo
	return 0;							//Izlazimo iz funkcije, javit cemo neku gresku.
	else
	{
		novi -> value = value;			//ako je rezervirano mjesto, vrijednost koju zelimo upisati stavljamo na novi atom.
		
		//printf("glavap = %d ", *glavap);
		
		if((*glavap == NULL) || (value <= (*glavap)->value))	//Provjeravamo trebamo li element upisati na pocetak liste
		{
			novi -> next = *glavap;
			*glavap = novi;
		}
		else
		{
			atom *p;
			//Pokrecemo for petlju bez pocetnog uvjeta. Ako je next komponenta onog na sto glava pokazuje razlicita od nule (dakle, ne radi se u kraju niza,
			//i ako na to sto pokazuje glava ima vrijednost manju od one koje zelimo upisati, pregledavamo sljedeci atom u listi. To cemo napraviti na jedan nacin
			//koji se isprva cini kompleksan, ali kad se uvjezba je lagan. Dakle, pretpostavit cemo da nas dupli pokazivac glavap poprima adresu u koju je zapisan
			//pokazivac sljedeceg elementa, tj. za novi pokazivac na glavu uzet cemo ono na sto glava pokazuje. Onda nam glava pokazuje na element nakon toga, pa smo
			//efektivno pomakli glavu za 1 mjestu udesno. Kad se petlja prekine, stigli smo do 1. veceg elementa, pa cemo na trenutnu lokaciju prespojiti nas novi.
			for(; (*glavap)->next && ((*glavap)->next)->value < value; glavap = &((*glavap) -> next));
				
			novi->next = (*glavap)->next;				//Sljedeci element na kojeg pokazuje novi ce sada biti element na koji pokazuje glava,
			(*glavap)->next = novi;						//a element na koji pokazuje glava ce sada biti nas atom novi. Time smo novi smjestili izmeðu prethodnog elementa i trenutnog.
		}
	}
	return 1;
}

int eraseatom(atom **glavap, int value)
{
	atom *temp;							//Definirajte neki privremeni atom.
	
	//Ovdje je ista fora kao i u funkciji za dodavanje, jedina razlika je u uvjetu: ovdje je važno da
	//nam glava ne pokazuje na NULL (tj. da nismo na kraju liste), te da nam trenutna vrijednost nije ona koju
	//zelimo izbrisati. Onaj trenutak kad udarimo u kraj, ili u vrijednost koju zelimo obrisat, for petlja staje.
	for(; *glavap && (*glavap)->value != value; glavap = &((*glavap)->next));
	
	if(*glavap)							//Ako for nije prekinut na kraju, tj. ako je element u listi naðen
	{
		temp = *glavap;					//Nas temp ce onda pokazivati na vrijednost koju zelimo izbrisati.
		*glavap = (*glavap)->next;		//Ono na sto glava pokazuje se odspaja, te glava sad pokazuje na sljedeci element.
		
		free(temp);						//Ovo je cijeli smisao postojanja temp-a - bez njega ne bismo mogli osloboditi element koji smo maknuli iz liste.
		return 1;						//Vracamo 1 sto znaci da je brisanje uspjelo.
	}
	else
	return 0;							//Ako nismo nasli element koji trazimo, vracamo 0.
}

atom *searchlist(atom *glava, int value)
{
	for(; glava != NULL; glava = glava -> next)	//Ovdje cemo direktno baratati sa glavom jer izmjenom u funkciji je necemo izmjeniti u glavnom programu.
	{
		if(glava->value == value)				//Ako je vrijednost na koju nasa glava (koja je sad zapravo samo pokazivac na element u listi) jednaka trazenoj
		return glava;							//vracamo pokazivac na taj element
	}
	return NULL;								//U suprotnom, vracamo 0, sto signalizira da element nije pronaðen.
}

void spc(int x)
{
     while(x--)
     printf("\n");
}

int main()
{
    srand(time(NULL));
    
    char *naredba = (char*)malloc(6 * sizeof(char)); 	//moguce naredbe su dodaj, brisi, trazi, sve su velicine 5 + 1
    int vrijednost;										//Vrijednost koju pisemo, brisemo ili trazimo
    
    atom *glava;										//Ovo je glava, ne glavap. Glavap virtualno postoji kao &glava;
    glava = NULL;
    
    printf("Ovaj program sluzi za upravljanje jednostrukom povezanom listom.\n");
    printf("Kljucne rijeci mogu se upisati kao bilo koja permutacija malih i velikih slova u vazecem poretku.\n\n");
    printf("Kljucna rijec \"dodaj\" dodati ce cijelobrojni element listi.\n");
    printf("Kljucna rijec \"brisi\" obrisati ce prvi jednaki element u listi ako takav postoji.\n");
    printf("Kljucna rijec \"trazi\" ce obavjestiti korisnika nalazi li se trazeni element u listi.\n");
    printf("Kako biste izasli iz programa, utipkajte \"ljac\" u bilo kojem obliku.");
    
    spc(2);
    
    do
    {
    	printf("Upisite naredbu [dodaj/brisi/trazi] i pripadajucu vrijednost: ");
    	scanf("%s", naredba);
    	
    	for(int i = 0; naredba[i] != 0; i++)
    	naredba[i] = tolower(naredba[i]);
    	
    	if(!strcmp(naredba, "ljac"))
    	{
    		printf("\nIzlazim...");
    		spc(2);
    		return 831016673;
    	}
    	
    	system("CLS");
    	
    	scanf("%d", &vrijednost);
    	
    	if(!strcmp(naredba, "dodaj"))
    	{
    		int errcode = add2list(&glava, vrijednost);
    		
    		if(errcode)
    		printf("Vrijednost %d je uspjesno dodana u listu!", vrijednost);
    		else
    		printf("Doslo je do greske prilikom dodavanja elementa u listu, pokusajte ponovo.");
    		
    		spc(1);
    	}
    	
    	else if(!strcmp(naredba, "brisi"))
    	{
    		int errcode = eraseatom(&glava, vrijednost);
    		
    		if(errcode)
    		printf("Vrijednost %d uspjesno je obrisana!", vrijednost);
    		else
    		printf("Element koji je trebalo obrisati ne nalazi se u listi, pokusajte ponovo.");
    		
    		spc(1);
    	}
    	
    	else if(!strcmp(naredba, "trazi"))
    	{
    		if(searchlist(glava, vrijednost))
    		printf("Element %d je u listi.\n", vrijednost);
    		else
    		printf("Element ne postoji.\n");
    		
    		spc(1);
    	}
    	
    	else
    	printf("Naredba je pogresno upisana!\n");
    	
    	printf("U ovom trenutku, sastav liste je:\n");
    	for(atom *p = glava; p; p = p -> next)
    	printf("%d ", p -> value);
    	
    	spc(2);
    }
	while(strcmp(naredba, "ljac"));

    spc(2);
    system("pause");
    return 0;
}