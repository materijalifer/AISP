#include<stdio.h>
#include<stdlib.h>
#include<time.h>

using namespace std;

void spc(int x)
{
     while(x--)
     printf("\n");
}

//Funkcija koja stvara nasumicno polje intova velicine velicina.
 int *randarr(short velicina)
{
	int *ret = (int*)malloc(velicina * sizeof(int));
	
	for(short i = 0; i < velicina; i++)	
	{
		ret[i] = rand()%1000;
		
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", ret[i]);
	}
	
	return ret;
}

//Funckija za ispis polja intova.
void ispis(int *polje, short velicina)
{
	for(short i = 0; i < velicina; i++)
	{
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", polje[i]);
	}
}

void shellsort(int *polje, short velicina)
{
	int j;							//Trebat ce nam kasnije izvan petlje u kojem bi definirao j
	
	for(int razmak = velicina/2; razmak > 0; razmak/=2)
	{
		for(int i = razmak; i < velicina; i++)		//Prvi kojeg usporeðujemo je na indeksu razmak. U 1. pokretanju
		{											//To je velicina/2, u 2. velicina/4, a u zadnjem 1.
			int t = polje[i];						//U t pohranjujemo trenutni element za koji provjeravamo je li manji od elementa koji mu je za razmak mjesta ulijevo.
			
			for(j = i; (j >= razmak) && (t < polje[j - razmak]); j -= razmak)	//Zapocinjemo sa indeksom i. Dok je nas j veci ili jednak razmaku i dok je t manji od njemu razmak mjesta ulijevo elementu,
			polje[j] = polje[j - razmak];										//Na mjesto koje trenutno gledamo, stavljamo element njemu razmak mjesta ulijevo.
			
			polje[j] = t;														//Na kraju, na j-ti element cemo staviti nas prvotni element t, jer smo našli gdje on treba doci.
		}																		//Cijeli ovaj proces zapravo prebriše posljednji broj koji smo gledali dok ne doðe do mjesta gdje element koji smo gledali pripada
	}																			//Oni koji su manji od njega se trenutno ne gledaju.
}

int main()
{
    srand(time(NULL));
    
    short velicina;
    printf("Unesite velicinu nasumicnog polja koje zelite sortirati: ");
    scanf("%d", &velicina);
    spc(1);
    
    int *polje;
    printf("Nasumicno polje je:\n");
    polje = randarr(velicina);
    spc(2);
    
    shellsort(polje, velicina);
    printf("Sortirano polje je:");
    ispis(polje, velicina);
    
    free(polje);

    spc(2);
    system("pause");
    return 0;
}