#include<stdio.h>
#include<stdlib.h>
#include<time.h>

using namespace std;

void spc(int x)
{
     while(x--)
     printf("\n");
}

//Zamijenjuje vrijednosti na adresama e1 i e2
void swap(int *e1, int *e2)
{
	int t = *e1;
	*e1 = *e2;
	*e2 = t;
}

//Selection sort algoritam
void selSort (int *polje, short velicina)
{
	short L = 0, ekstrem = 0, i;						//L je prvi indeks kojeg provjeravamo u nekom ciklusu,
														//ekstrem je indeks na kojem je najmanji/najveci broj.
	for(; L < (velicina - 1); L++)						//Provjeravamo do velicina - 1 jer kad doðemo do zadnjeg, on je na svojem mjestu.
	{
		for(ekstrem = L, i = L + 1; i < velicina; i++)	//Pretpostavimo da je ekstrem na prvom indeksu, pocinjemo provjeru od sljedeceg
		{
			if(polje[i] < polje[ekstrem])				//Ako je element na trenutnom indeksu manji od elementa na indeksu ekstrem,
			ekstrem = i;								//novi ekstrem je na indeksu i.
		}
		
		swap(&polje[ekstrem], &polje[L]);				//Na kraju izvrsavanja zamijenjujemo elemente
	}
}

//Funckija za ispis polja intova.
void ispis(int *polje, short velicina)
{
	for(short i = 0; i < velicina; i++)
	{
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", polje[i]);
	}
}

//Funkcija koja stvara nasumicno polje intova velicine velicina.
 int *randArr(short velicina)
{
	int *ret = (int*)malloc(velicina * sizeof(int));
	
	for(short i = 0; i < velicina; i++)	
	{
		ret[i] = rand()%1000;
		
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", ret[i]);
	}
	
	return ret;
}

int main()
{
    srand(time(NULL));
    
    short velicina;
    printf("Unesite velicinu nasumicnog polja koje zelite sortirati: ");
    scanf("%d", &velicina);
    spc(1);
    
    int *polje;
    printf("Nasumicno polje je:\n");
    polje = randArr(velicina);
    spc(2);
    
    selSort(polje, velicina);
    printf("Sortirano polje je:");
    ispis(polje, velicina);
    
    free(polje);

    spc(2);
    system("pause");
    return 0;
}