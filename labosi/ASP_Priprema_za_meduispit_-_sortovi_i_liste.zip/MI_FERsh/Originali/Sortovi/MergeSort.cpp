#include<stdio.h>
#include<stdlib.h>
#include<time.h>

using namespace std;

void spc(int x)
{
     while(x--)
     printf("\n");
}

//Funkcija koja stvara nasumicno polje intova velicine velicina.
int *randarr(short velicina)
{
	int *ret = (int*)malloc(velicina * sizeof(int));
	
	for(short i = 0; i < velicina; i++)	
	{
		ret[i] = rand()%1000;
		
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", ret[i]);
	}
	
	return ret;
}

//Funckija za ispis polja intova.
void ispis(int *polje, short velicina)
{
	for(short i = 0; i < velicina; i++)
	{
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", polje[i]);
	}
}

//pocetak je prvi indeks, a kraj je zadnji indeks polja koje kopiramo.
void kopirajpolje(int *izpolja, int pocetak, int kraj, int *upolje)
{
    for(int i = pocetak; i < kraj; i++)
        upolje[i] = izpolja[i];
}

//Spajamo polje[pocetak:sredina-1] i polje[sredina:kraj-1] u ppolje[pocetak:kraj-1]
void merge(int *polje, int pocetak, int sredina, int kraj, int *ppolje)
{
	//Na pocetku definiramo i kao prvi element 1. podpolja, a j kao prvi element 2. podpolja.
    int i = pocetak, j = sredina;
    
    //k ce biti indeks novonastalog polja, pa se petlja vrti dok god se svi elementi ne upišu.
    for (int k = pocetak; k < kraj; k++) 
	{
        if (i < sredina && (j >= kraj || polje[i] <= polje[j])) 	//Dok postoji 1. podpolje I ako je ili 2. podpolje doslo do kraja, ili je trenutni element u 1. podpolju manji ili jednak trenutnom elementu u 2. podpolju
        ppolje[k] = polje[i++];										//Na trenutni element pomocnog polja upisujemo trenutni element 1. podpolja.
        
		else 														//U suprotnom, treba upisati trenutni element 2. podpolja, jer je on manji.
        ppolje[k] = polje[j++];										//U oba slucaja nakon pridruživanja povecavamo pokazivac na element jer smo ga upisali.
    } 
}

//Ova funkcija cijepa polje do brojeva, koje smatra sortiranima. Za ostale se rekurzivno vraca, te ih sortira. Kad sortira neko podpolje, vraca se korak unazad i ili sortira duplo vece podpolje, ili desno podpolje iste velicine.
void cijepaj(int *ppolje, int pocetak, int kraj, int *polje)
{
    if(kraj - pocetak < 2)								//Ako ovo proðe, znaci da je udaljenost pocetka i kraja barem 1, tj. oni su susjedni, tj. velicina podpolja je 1 (jer kraj nije dio podpolja)
    return;
    
    //Nalazimo aritmeticku sredinu ako je podpolje velicine >= 2.
    int sredina = (kraj + pocetak) / 2;
    
    cijepaj(polje, pocetak, sredina, ppolje);			//Cijepamo nasa novo lijevo podpolje,
    cijepaj(polje, sredina, kraj, ppolje); 				//a nakon njega odmah i desno podpolje.
    
    //Nasa funkcija cijepaj automatski i sortira podpolja, pa ih sad samo treba spojiti u vece polje
    //Treba zamijetiti da je sad ulazno polje pomocno, a polje u koje kopirmo nase pravo polje
    //Ovim dobivamo to da ne trebamo sve stalno kopirati u pomocno polje, vec naizmjence kopiramo u pomocno, pa u izvorno, itd.
    merge(ppolje, pocetak, sredina, kraj, polje);
}

//Ovo je nasa jezgra mergesort algoritma, iako nije previše funkcionalna - prvo cemo samo kopirati cijelo polje u podpolje
//A zatim poceti sa cijepanjem. Treba zamijetiti da je redoslijed ulaznog i pomocnog polja opet obrnut kao i iznad.
void mergesort(int *polje, int *ppolje, int velicina)
{
    kopirajpolje(polje, 0, velicina, ppolje);		//Ovime osiguravamo da nam je ppolje isto kao i polje. Zato radi linija ispod ove.
    cijepaj(ppolje, 0, velicina, polje);			//Cijepamo iz pomocnog u izvorno polje. Kod sljedeceg cijepanja ce se to obrnuti.
    												//Ako zelite shvatiti sto se dogaða ako obrnemo ovaj redoslijed, obrnite ga, i zapravo
}													//cete dobiti polje koje treba merge-ati.

int main()
{
    srand(time(NULL));
    
    short velicina;
    printf("Unesite velicinu nasumicnog polja koje zelite sortirati: ");
    scanf("%d", &velicina);
    spc(1);
    
    int *polje;
    printf("Nasumicno polje je:\n");
    polje = randarr(velicina);
    int *ppolje = (int*)malloc(velicina * sizeof(int));
    spc(2);
    
    mergesort(polje, ppolje, velicina);
    printf("Sortirano polje je:");
    ispis(polje, velicina);
    
    free(polje);
    free(ppolje);

    spc(2);
    system("pause");
    return 0;
}