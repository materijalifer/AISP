#include<stdio.h>
#include<stdlib.h>
#include<time.h>

using namespace std;

void spc(int x)
{
     while(x--)
     printf("\n");
}

//Zamijenjuje vrijednosti na adresama e1 i e2
void swap(int *e1, int *e2)
{
	int t = *e1;
	*e1 = *e2;
	*e2 = t;
}

//Funkcija koja stvara nasumicno polje intova velicine velicina.
 int *randArr(short velicina)
{
	int *ret = (int*)malloc(velicina * sizeof(int));
	
	for(short i = 0; i < velicina; i++)	
	{
		ret[i] = rand()%1000;
		
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", ret[i]);
	}
	
	return ret;
}

//Funckija za ispis polja intova.
void ispis(int *polje, short velicina)
{
	for(short i = 0; i < velicina; i++)
	{
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", polje[i]);
	}
}

void Nsort (int *polje, short velicina)
{
	for(short i = 1; i < velicina; i++)								//Pocinjemo od 2. elementa u nizu, idemo do kraja.
	{
		for(short J = i; (J > 0) && (polje[J-1] > polje[J]); J--)	//Dok je clan prije J-tog indeksa veci od clana na J-tom,
		swap(&polje[J], &polje[J-1]);								//zamijenjujemo J-ti i (J - 1). clan. Na taj nacin
	}																//kao da guramo trenutni clan na svoje mjesto.
}																	// U [3 1 2 4] =>  [3 <- 1 2 4], [1 3 <- 2 4], [1 2 3 4], niz je sortiran.

int main()
{
    srand(time(NULL));
    
    short velicina;
    printf("Unesite velicinu nasumicnog polja koje zelite sortirati: ");
    scanf("%d", &velicina);
    spc(1);
    
    int *A;
    printf("Nasumicno polje je:\n");
    A = randArr(velicina);
    spc(2);
    
    Nsort(A, velicina);
    printf("Sortirano polje je:");
    ispis(A, velicina);
    
    free(A);

    spc(2);
    system("pause");
    return 0;
}