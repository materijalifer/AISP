#include<stdio.h>
#include<stdlib.h>
#include<time.h>

using namespace std;

void spc(int x)
{
     while(x--)
     printf("\n");
}

//Zamijenjuje vrijednosti na adresama e1 i e2
void swap(int *e1, int *e2)
{
	int T = *e1;
	*e1 = *e2;
	*e2 = T;
}

//Funkcija koja stvara nasumicno polje intova velicine velicina.
 int *randarr(short velicina)
{
	int *ret = (int*)malloc(velicina * sizeof(int));
	
	for(short i = 0; i < velicina; i++)	
	{
		ret[i] = rand()%1000;
		
		if(i%15 == 0)
		spc(1);
		
		printf("%3d ", ret[i]);
	}
	
	return ret;
}

//Funckija za ispis polja intova.
void ispis(int *polje, short velicina)
{
	for(short K = 0; K < velicina; K++)
	{
		if(K%15 == 0)
		spc(1);
		
		printf("%3d ", polje[K]);
	}
}

void bubbleSort(int *polje, short velicina)
{
	short cisto;									//cisto je varijabla koja je 1 ako je polje sortirano,
													//a 0 ako nije sortirano
	do
	{
		cisto = 1;									//Pretpostavimo da je polje sortirano
		
		for(short i = 0; i < (velicina - 1); i++)
		{
			if(polje[i] > polje[i+1])				//Ako je trenutni element veci od sljedeceg, treba ih zamijeniti.
			{
				cisto = 0;							//Ako proðe if, polje nije bilo sortirano
				swap(&polje[i], &polje[i+1]);		//Zamijenjuje se trenutni i sljedeci element.
			}
		}
	}
	while(!cisto);
}

int main()
{
    srand(time(NULL));
    
    short velicina;
    printf("Unesite velicinu nasumicnog polja koje zelite sortirati: ");
    scanf("%d", &velicina);
    spc(1);
    
    int *polje;
    printf("Nasumicno polje je:\n");
    polje = randarr(velicina);
    spc(2);
    
    bubbleSort(polje, velicina);
    printf("Sortirano polje je:");
    ispis(polje, velicina);
    
    free(polje);

    spc(2);
    system("pause");
    return 0;
}