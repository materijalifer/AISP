FERsh je program koji osvje�ava rje�enja preko interneta, tako da kad Edit na F2N-u timeout-a, ja mogu promijeniti rje�enja ukoliko bude neka gre�ka.
Svrha je neponavljanje blagoreceno zajeba sa ARH1 labosa. Priprema za rad ovog programa (koja je obavezna ukoliko �elite da radi) nalazi se na: http://materijali.fer2.net/File.28143.aspx
Ni�ta stra�no, manje od minute jednokratnog posla.

Ako ne �elite koristiti program, ili nemate 64-bitne Windowse, a�urirani kodovi nalaze se na:

Zadatak 1)		http://pastebin.com/raw/NGW2Kk52
Zadatak 2)		http://pastebin.com/raw/Q4KKLXGQ
Zadatak 3)		http://pastebin.com/raw/WHDTyUuR
Zadatak 4)		http://pastebin.com/raw/DqGxaPGS
Zadatak 5)		http://pastebin.com/raw/JUHZw9As
Zadatak 6)		http://pastebin.com/raw/RvKMzNxv
Zadatak 7)		http://pastebin.com/raw/hHZfUaWS
Zadatak 8)		http://pastebin.com/raw/gSeC3Xnx
Zadatak 9)		http://pastebin.com/raw/ua20jGtk
Zadatak 10)		http://pastebin.com/raw/jM3t1a8m


Za bilo kakva pitanja ili primjedbe, javite se u box "Ljac" na F2N.