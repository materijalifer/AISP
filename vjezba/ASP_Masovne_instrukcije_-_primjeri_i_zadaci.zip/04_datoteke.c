#include "asp_massh.h"
#include <stdio.h>

int main() {
	FILE *f;
	
	f = fopen("dat.txt", "w");
	
	return 0;
}
