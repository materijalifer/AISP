#include <stdio.h>

int main() {
	char* a, b;
	printf("%d %d\n", sizeof(a)*8, sizeof(b)*8);
	return 0;
}
