#include <iostream>
using namespace std;

#define ispisiVarijablu(a) cout << ": " << #a << " = " << (a) << endl;
#define ispisiPointer(a) cout << ": " << #a << " = " << (a) << endl;
#define ispisiVrijednostPokazivanogSa(a) cout << ": *(" << #a << ") = " << (*(a)) << endl;
#define noviRed() cout << endl;
#define fancyNoviRed() cout << "     #####" << endl;
#define noviDio(a) cout << "\n# " << (a) << " #\n";
