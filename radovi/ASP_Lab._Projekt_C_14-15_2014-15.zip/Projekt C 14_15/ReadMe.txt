Prvi i drugi dio projekta su odvojeni kodovi.
U prvom dijelu kada treba mijenati nacin adresiranja, imas labelu na vrhu:
#define ADRESA Adresa3 ,
i samo promijenis broj kako bi dobio zeljeni nacin adresiranja.

Jedina potrebna datoteka za oba dijela je podaci.dat,
ostale datoteke rade programi.
Bitno je da kodovi i datoteka budu u istoj mapi kako bi sve radilo 
kako treba. Oba koda su to�na i dobiveno je za njih 5/5 bodova.